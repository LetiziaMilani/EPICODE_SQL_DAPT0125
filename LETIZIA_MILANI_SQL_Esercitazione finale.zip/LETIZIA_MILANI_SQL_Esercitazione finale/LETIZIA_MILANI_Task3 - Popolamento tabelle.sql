-- Task 3

-- Seleziono il database di interesse
USE toysgroup;

-- Popolo le tabelle con i dati

-- Tabella 'Category'

INSERT INTO Category (CategoryID, CategoryName)
VALUES 
(1, 'Bambole')
, (2, 'Peluche')
, (3, 'Giochi di società')
, (4, 'Costruzioni')
, (5, 'Giochi musicali')
, (6, 'Giochi di ruolo')
, (7, 'Giochi di magia')
, (8, 'Giochi da spiaggia')
, (9, 'Set da disegno')
, (10, 'Giochi da collezione');

SELECT *
FROM Category;

-- Tabella 'Product'

INSERT INTO Product (ProductID, ProductName, CategoryID, ListPrice)
VALUES 
 (1, 'Amici del Cuore', 1, 24.90)
, (2, 'Orsetto Coccolone', 2, 19.90)
, (3, 'Sfida delle Parole', 3, 29.90)
, (4, 'Costruisci la Città', 4, 34.90)
, (5, 'Piccolo Musicista', 5, 27.90)
, (6, 'Il Piccolo Chef', 6, 21.50)
, (7, 'Scuola di Magia', 7, 31.90)
, (8, 'Castelli di Sabbia', 8, 14.90)
, (9, 'Colora e Crea', 9, 12.90)
, (10, 'Collezione Magica', 10, 16.50)
, (11, 'Bambola Sofia', 1, 22.90)
, (12, 'Coniglietto Sonoro', 2, 18.90)
, (13, 'Quiz Famiglia', 3, 25.90)
, (14, 'Costruzioni Lego', 4, 39.90)
, (15, 'Tamburo Allegro', 5, 20.90)
, (16, 'Dottore per Gioco', 6, 23.90)
, (17, 'Incantesimi Facili', 7, 28.90)
, (18, 'Giochi da Spiaggia', 8, 13.90)
, (19, 'Disegna con Me', 9, 11.90)
, (20, 'Mini Collezione', 10, 15.90);

SELECT * 
FROM Product;

-- Tabella 'SalesRegion'

INSERT INTO SalesRegion (SalesRegionID, SalesRegionName)
VALUES 
 (1, 'Nord America')
, (2, 'Europa Ovest')
, (3, 'Europa Est')
, (4, 'Asia Est')
, (5, 'Asia SudEst')
, (6, 'Oceania')
, (7, 'Sud America');

SELECT *
FROM SalesRegion;

-- Tabella 'Region'

INSERT INTO Region (RegionID, RegionName, SalesRegionID)
VALUES 
 (1, 'Italia', 2)
, (2, 'Francia', 2)
, (3, 'Germania', 2)
, (4, 'Usa', 1)
, (5, 'Canada', 1)
, (6, 'Giappone', 4)
, (7, 'Corea del Sud', 4)
, (8, 'Cina', 4)
, (9, 'Indonia', 5)
, (10, 'Tailandia', 5)
, (11, 'Australia', 6)
, (12, 'Nuova Zelanda', 6)
, (13, 'Brasile', 7)
, (14, 'Argentina', 7)
, (16, 'Messico', 1)
, (17, 'Regno Unito', 2)
, (18, 'Repubblica Ceca', 3)
, (19, 'Vietnam', 5)
, (20, 'Filippine', 5)
, (21, 'Singapore', 5);

SELECT *
FROM Region;

-- Tabella Sales

INSERT INTO Sales (SalesID, SalesDate, ProductID, RegionID, SalesQuantity, UnitPrice, TotalProductCost, SalesAmount)
VALUES
 ('TG0001', '2021-05-29', 4, 7, 2, 31.41, 43.97, 62.82)
, ('TG0002', '2020-09-22', 4, 2, 4, 31.41, 87.95, 125.64)
, ('TG0003', '2025-01-10', 4, 2, 8, 31.41, 175.90, 251.28)
, ('TG0004', '2020-10-04', 4, 8, 3, 31.41, 65.96, 94.23)
, ('TG0005', '2024-10-01', 4, 17, 7, 31.41, 153.91, 219.87)
, ('TG0006', '2025-03-16', 4, 1, 8, 31.41, 175.90, 251.28)
, ('TG0007', '2024-12-11', 4, 8, 6, 31.41, 131.92, 188.46)
, ('TG0008', '2025-02-25', 9, 8, 6, 11.61, 48.76, 69.66)
, ('TG0009', '2024-11-25', 5, 3, 7, 25.11, 123.04, 175.77)
, ('TG0010', '2024-02-09', 10, 7, 1, 14.85, 10.39, 14.85)
, ('TG0011', '2022-07-08', 15, 17, 3, 18.81, 39.50, 56.43)
, ('TG0012', '2020-07-09', 6, 8, 9, 19.35, 121.91, 174.15)
, ('TG0013', '2021-04-17', 19, 3, 5, 10.71, 37.48, 53.55)
, ('TG0014', '2022-04-30', 2, 3, 3, 17.91, 37.61, 53.73)
, ('TG0015', '2023-02-09', 9, 1, 10, 11.61, 81.27, 116.10)
, ('TG0016', '2023-10-01', 12, 1, 8, 17.01, 95.26, 136.08)
, ('TG0017', '2024-12-09', 18, 2, 1, 12.51, 8.76, 12.51)
, ('TG0018', '2024-10-16', 19, 6, 2, 10.71, 14.99, 21.42)
, ('TG0019', '2022-10-17', 5, 8, 4, 25.11, 70.31, 100.44)
, ('TG0020', '2024-11-01', 7, 8, 5, 28.71, 100.48, 143.55);

SELECT * 
FROM Sales;



