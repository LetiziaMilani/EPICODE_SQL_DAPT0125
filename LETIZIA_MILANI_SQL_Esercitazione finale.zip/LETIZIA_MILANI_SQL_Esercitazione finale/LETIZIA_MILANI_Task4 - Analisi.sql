-- Task 4

-- Seleziono il database di interesse
USE toysgroup;

-- Esercizio 1
-- Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’univocità dei valori di 
-- ciascuna PK (una query per tabella implementata);

-- Tabella Category
SELECT CategoryID
, COUNT(*)
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) = 1;

-- Tabella Product
SELECT ProductID
, COUNT(*)
FROM Product
GROUP BY ProductID
HAVING COUNT(*) = 1;

-- Tabella SalesRegion
SELECT SalesRegionID
, COUNT(*)
FROM SalesRegion
GROUP BY SalesRegionID
HAVING COUNT(*) = 1;

-- Tabella Region
SELECT RegionID
, COUNT(*)
FROM Region
GROUP BY RegionID
HAVING COUNT(*) = 1;

-- Tabella Sales
SELECT SalesID
, COUNT(*)
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) = 1;

-- Esercizio 2
-- Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, 
-- la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla 
-- condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False);

SELECT A.SalesID AS CodiceDocumento
, A.SalesDate AS Data
, B.ProductName AS Prodotto
, C.CategoryName AS Categoria
, D.RegionName AS Stato
, E.SalesRegionName AS AreaVendita
, CASE WHEN (DATEDIFF(CURRENT_DATE, A.SalesDate)) > 180 THEN TRUE 
  ELSE FALSE 
  END AS CampoBooleano
FROM Sales AS A
INNER JOIN 
Product AS B
ON A.ProductID = B.ProductID
INNER JOIN
Category AS C
ON B.CategoryID = C.CategoryID
INNER JOIN
Region AS D
ON A.RegionID = D.RegionID
INNER JOIN
SalesRegion AS E
ON D.SalesRegionID = E.SalesRegionID;

-- Esercizio 3
-- Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate 
-- nell’ultimo anno censito. (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). 
-- Nel result set devono comparire solo il codice prodotto e il totale venduto;

SELECT ProductID AS CodiceProdotto
, SUM(SalesAmount) AS TotaleVenduto
FROM Sales
GROUP BY ProductID
HAVING SUM(SalesAmount) > (SELECT AVG(SalesAmount)
                           FROM Sales
                           WHERE YEAR(SalesDate) = (
                           SELECT MAX(YEAR(SalesDate)) FROM Sales)
);

-- Esercizio 4
-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno;

SELECT B.ProductName AS Prodotto
, YEAR(A.SalesDate) AS Anno
, SUM(A.SalesAmount) AS FatturatoTotale 
FROM Sales AS A	
INNER JOIN
Product AS B
ON A.ProductID = B.ProductID
GROUP BY YEAR(A.SalesDate), B.ProductName
ORDER BY Anno; 

-- Esercizio 5
-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente;

SELECT YEAR(A.SalesDate) AS Anno
, B.RegionName AS Stato
, SUM(A.SalesAmount) AS FatturatoTotale
FROM Sales AS A
INNER JOIN
Region AS B
ON A.RegionID = B.RegionID
GROUP BY YEAR(A.SalesDate), B.RegionName
ORDER BY Anno, FatturatoTotale DESC;

-- Esercizio 6
-- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?;

SELECT C.CategoryName AS Categoria
, SUM(A.SalesQuantity) AS QuantitaTotaleVenduta
, SUM(SalesAmount) AS TotaleVenduto
FROM Sales AS A
INNER JOIN 
Product AS B
ON A.ProductID = B.ProductID
INNER JOIN
Category AS C
ON B.CategoryID = C.CategoryID
GROUP BY C.CategoryName
ORDER BY QuantitaTotaleVenduta DESC, TotaleVenduto DESC;  -- La categoria di articoli maggiormente richiesta è 'Costruzioni'

-- Esercizio 7
-- Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.

-- Metodo con SUBQUERY

SELECT ProductID AS CodiceProdotto
, ProductName AS Prodotto
FROM Product
WHERE ProductID NOT IN (SELECT ProductID
						FROM Sales);

-- Metodo con LEFT JOIN

SELECT A.ProductID AS CodiceProdotto
, A.ProductName AS NomeProdotto
, B.SalesAmount AS VenditaTotale  -- Espongo SalesAmount per mostrare che la vendita è pari a NULL
FROM Product AS A
LEFT JOIN
Sales AS B
ON A.ProductID = B.ProductID
WHERE B.ProductID IS NULL;              

-- Esercizio 8
-- Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, 
-- nome prodotto, nome categoria);

CREATE VIEW LM_Prodotti AS 
SELECT A.ProductID AS CodiceProdotto
, A.ProductName AS Prodotto
, B.CategoryName AS Categoria
FROM Product AS A
INNER JOIN 
Category AS B
ON A.CategoryID = B.CategoryID;

-- Esercizio 9
-- Creare una vista per le informazioni geografiche;

CREATE VIEW LM_InfoGeografiche AS
SELECT A.RegionName AS Regione
, B.SalesRegionName AS RegioneVendita
FROM Region AS A
INNER JOIN
SalesRegion AS B
ON A.SalesRegionID = B.SalesRegionID;

-- Le viste non comunicano tra loro
-- Se volessi creare delle viste comunicanti tra loro potrei proseguire come:

-- Vista sui prodotti

CREATE VIEW LM_Prodotti2 AS
SELECT A.ProductID AS CodiceProdotto
, B.ProductName AS Prodotto
, C.CategoryName AS Categoria
, A.RegionID AS CodiceStato
FROM Sales AS A
INNER JOIN 
Product AS B
ON A.ProductID = B.ProductID
INNER JOIN
Category AS C
ON B.CategoryID = C.CategoryID;

-- Vista sulle informazioni geografiche

CREATE VIEW LM_InfoGeografiche2 AS
SELECT A.ProductID AS CodiceProdotto
, A.RegionID AS CodiceStato
, B.RegionName AS Stato
, C.SalesRegionName AS AreaVendita
FROM Sales AS A
INNER JOIN
Region AS B
ON A.RegionID = B.RegionID
INNER JOIN
SalesRegion AS C
ON B.SalesRegionID = C.SalesRegionID;

-- In questo caso, ho creato due viste collegate fra loro tramite i campi (ProductID e RegionID) relative ai prodotti che sono stati venduti 
-- tenendo traccia delle informazioni su codice prodotto, nome prodotto, categoria prodotto, codice stato, nome stato e area di vendita.



        
       
        
    
    

   
