-- Task 2
-- Creo il database 'toysgroup';
CREATE SCHEMA toysgroup;

-- Seleziono il database appena creato;

USE toysgroup; 

-- Creo le tabelle da inserire nel database;

-- Tabella 'Category'

CREATE TABLE Category (
CategoryID INT
, CategoryName VARCHAR(50)
, CONSTRAINT pk_CategoryID PRIMARY KEY (CategoryID)
);

-- Tabella 'Product'

CREATE TABLE Product (
ProductID INT
, ProductName VARCHAR(50)
, CategoryID INT
, ListPrice DECIMAL(5,2)
, CONSTRAINT pk_ProductID PRIMARY KEY (ProductID)
, CONSTRAINT fk_Category_Product FOREIGN KEY (CategoryID)
REFERENCES Category (CategoryID)
); 

-- Tabella 'SalesRegion'

CREATE TABLE SalesRegion (
SalesRegionID INT
, SalesRegionName VARCHAR(50)
, CONSTRAINT pk_SalesRegionID PRIMARY KEY (SalesRegionID)
); 

-- Tabella 'Region'

CREATE TABLE Region (
RegionID INT
, RegionName VARCHAR(50)
, SalesRegionID INT
, CONSTRAINT pk_RegionID PRIMARY KEY (RegionID)
, CONSTRAINT fk_SalesRegion_Region FOREIGN KEY (SalesRegionID)
REFERENCES SalesRegion (SalesRegionID)
);

-- Tabella 'Sales'

CREATE TABLE Sales (
SalesID	CHAR(6)
, SalesDate	DATE
, ProductID	INT
, RegionID INT
, SalesQuantity INT	
, UnitPrice DECIMAL(5,2)
, TotalProductCost DECIMAL (5,2)
, SalesAmount DECIMAL (5,2)
, CONSTRAINT pk_SalesID PRIMARY KEY (SalesID)
, CONSTRAINT fk_Product_Sales FOREIGN KEY (ProductID)
REFERENCES Product (ProductID)
, CONSTRAINT fk_Region_Sales FOREIGN KEY (RegionID)
REFERENCES Region (RegionID)
);



